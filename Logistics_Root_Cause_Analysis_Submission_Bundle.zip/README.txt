LOGISTICS ROOT-CAUSE ANALYSIS – PROJECT BUNDLE
Important: all records are synthetic educational data, not actual company records.
Contents:
- Logistics_Root_Cause_Analysis_Report.docx: final report and management memo
- YuvaIntern_Project_Description.txt: >200-word portal description
- data/: raw and cleaned shipments, hubs, vehicles, routes, warehouse scans
- outputs/: KPI tables, hypothesis log, data-quality audit, model sensitivity
- figures/: charts used in the report
- analysis.py: reproducible statistical analysis script
- POWER_BI_DASHBOARD_GUIDE.txt: Power BI dashboard build instructions and DAX
Scope note: 150,000 unique shipments are provided, not 1.5 million. Expand only if the evaluator requires the full stated scale.

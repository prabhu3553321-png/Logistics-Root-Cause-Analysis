# Reproducible analysis script for cleaned shipments
import pandas as pd
import numpy as np
from scipy.stats import ttest_ind, chi2_contingency
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score

df = pd.read_csv("data/shipments_clean.csv")
df["order_timestamp"] = pd.to_datetime(df["order_timestamp"])
df["quarter"] = np.where(df["order_timestamp"].dt.month <= 3, "Q1", "Q2")
df["delayed"] = (df["delivery_status"] == "Delayed").astype(int)

q1, q2 = df[df.quarter == "Q1"], df[df.quarter == "Q2"]
print("Quarterly late rates:", df.groupby("quarter").delayed.mean())

for col in ["warehouse_delay_min", "traffic_delay_min"]:
    stat, p = ttest_ind(q1[col], q2[col], equal_var=False)
    print(col, "Welch t-test:", stat, p)

for col in ["vehicle_breakdown", "hub_name", "customer_segment", "service_type"]:
    table = pd.crosstab(df[col], df.delayed)
    chi2, p, dof, expected = chi2_contingency(table)
    print(col, "chi-square:", chi2, "p:", p)

features = ["warehouse_delay_min", "traffic_delay_min", "vehicle_breakdown",
            "distance_km", "vehicle_age_years"]
X = df[features].copy()
X["quarter_q2"] = (df.quarter == "Q2").astype(int)
X = pd.concat([X, pd.get_dummies(
    df[["hub_name", "customer_segment", "service_type"]],
    drop_first=True, dtype=float)], axis=1)
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=500))
model.fit(X, df.delayed)
print("In-sample AUC:", roc_auc_score(df.delayed, model.predict_proba(X)[:, 1]))
